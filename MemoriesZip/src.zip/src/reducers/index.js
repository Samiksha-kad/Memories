import { combineReducers } from "redux";

import posts from './postsReducers'


export default combineReducers({
    posts,
});